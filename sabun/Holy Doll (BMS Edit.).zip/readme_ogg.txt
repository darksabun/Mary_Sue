これはDTXパッケージ「DTX STARTER PACK 2」にあるtaqumi様のHoly Dollという曲をBMS化したものです。
もうエープリルフールだし、意表を突きたいなぁと思って急いで作りましたがどう受け取られるか分かりません…
せめて誰が作ったのか書き記して、自己責任で公開する方が良いかも。無許可で移植したので問題になると消します

よろしくお願いいたします。 
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2023/04/01

wav版ダウンロード：https://mega.nz/file/7wVAmIoK#8ZZdWiCtwT1Ccv5kLYzSJ8fSZ82c-1oqE5UzonQCaxs