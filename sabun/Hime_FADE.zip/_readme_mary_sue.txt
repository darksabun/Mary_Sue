呪われた姫様と純白の箱庭 [FADE]

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=324&event=140
推定レベル：★10-11? (sl7程度)
同梱hime [A].bms基準、検出されたズレ抜けは全部キー音切れのせいで発生したものです。

よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/)
2022/12/11